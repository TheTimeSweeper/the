# Electrician In the Field
- Adds the Tesla Trooper, who can construct Tesla Coil Towers to help him fry enemies.
- Fully fleshed out
  - Item displays and ragdoll
  - Fully animated (but by me so y'know)
  - Skills++ support
- Fully multiplayer compatible
- Y'all remember Red Alert 2?

[![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/Release/readme/CSS.png)]()

Anything you'd like to say about the guy, ping me (`TheTimesweeper#5727`) on the ror2 modding discord or the enforcer discord (https://discord.gg/csaEQDnMH8). As a first release, I'll be taking a close look at feedback.
___
## Overview
Based on Tesla Trooper from Red Alert 2, but with SkeletorChampion coming in and saying "nah I'm model him to fit RoR2, and look awesome, and my dong is enormous".  
Tesla Trooper is a mid-range bruiser on his own, and an all-range monster when he builds his Tesla Tower.  

[![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/Release/readme/zaps_combined.png)]()
[![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/theUnityProject/Assets/_Kniggas/TeslaTrooper/TeslaBundle/Icons/texIconTeslaTrooper.png)]()

## Credits
SkeletorChampion - Made the character model, which kicked off the mod. Without him, the mod wouldn't exist.  
Violet Chaolan - wwise sound help  
SweeperSecret - icons,  <3  
Moffein - consult, savior  
DeegerDill - consult  
Westwood Studios - sounds, inspiration  

## Future Plans (that I may or may not get to)
- Alt skills
- Achievements
- custom lightningorb effects (help)
- improved animations (help)
- Scepter and vr and all those fun stuffs

___
for no particular reason I made a cool skin for minecraft check it out   
[![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/theUnityProject/Assets/_Kniggas/TeslaTrooper/TeslaBundle/textures/MC/MCSkin.png)]()
___
## Changelog

`0.0.1`
- c: