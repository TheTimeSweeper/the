# Aliem
- When will invasion come out that shit's gonna be fun
- wip
- happy halloween c:

Anything you'd like to say about the guy, ping me (`TheTimesweeper#5727`) on the ror2 modding discord or the enforcer discord (https://discord.gg/ZZzmFgDbCH).

[![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/Release/Aliem/readme/aliem.png)]()

## Credits
Dotflare - Model  
The Behemoth - inspiration, sounds 

## Knonw Issues
- multiplayer not tested at all
- riding not tested on all enemies so there's probably some jank instances
- might be fun might not be fun idk!!

## Future Plans (that I may or may not get to)
- finish him lol
- planned kit 
  - m1 - mash to shoot hold to charge
  - m2 - dive (current shift)
  - shift - fire trail from invasion
  - r - mutations from invasion (so still grenade lol)
- better effects maybe
- Item displays

## Changelog
`0.1.0`
- c: