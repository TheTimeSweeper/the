# Aliem
- When will alien hominid invasion come out that shit's gonna be fun
- happy halloween c:
- multiplayer compatible!

Anything you'd like to say about the guy, ping me (`TheTimesweeper#5727`) on the ror2 modding discord or the enforcer discord (https://discord.gg/ZZzmFgDbCH).

[![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/Release/Aliem/readme/aliem.png)]()

## Credits
Dotflare - Model  
The Behemoth - inspiration, sounds 

## Known Issues
- multiplayer
  - animations will get stuck sometimes. 
  - all funcitonality will work fine on your screen, but for others animations may be wonky
- riding not tested on all enemies so there's probably some jank instances
- might be fun might not be fun idk!!

## Future Plans (that I may or may not get to)
- finish him lol
- planned kit 
  - m1 - mash to shoot hold to charge
  - m2 - dive (current shift)
  - shift - fire trail from invasion
  - r - mutations from invasion (so still grenade lol)
- better effects maybe
- more sounds
- replace pod with spaceship that crashes
- ~~Item displays~~

## Changelog
`0.3.0`
- fixed projectiles in multiplayer
- fixed riding error spam in multiplayer
- networked riding position for clients. 
  - *each player will see their proper riding position on their screen, but on other screens they will floating behind*
- can now ride allies, which gives them a movement buff
  - *was already giving enemies a movement buff to simulate panicking. simply applies to allies as well*
- chomp now heals for 10% of max health
- borrowed some sounds from the game for his projectiles' impacts
- added his upper and lower jaw to ragdoll

*likely (hopefully, barring bugs) my last update for this guy until I sometime later decide to revisit him*  
*have fun and thanks for havin fun c:*

`0.2.1`
- fixed another bug with ridden enemies dying causing lockups when certain mods were installed
- fixed character collider causing him to spawn through the floor out of the pod
  
`0.2.0`
- added item displays
- chomp now decapitates enemies if it kills them
- fixed bug with riding certain entities
- adjusted character collider to more suit his tiny body

`0.1.0`
- c: