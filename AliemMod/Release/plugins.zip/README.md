# Aliem
- ~~When will alien hominid invasion come out that shit's gonna be fun~~ it's out and it is fun indeed
- happy halloween modjam 2022 c:
- multiplayer compatible!
- overly configurable
- scepter support, emote support
- somewhat-ror-friendly version in config

Anything you'd like to say about the guy, ping me (`thetimesweeper`) on the ror2 modding discord or the enforcer discord (https://discord.gg/GgjjDvStcV).

## SotS fuckery. These issues are likely out of my control until gearbox fixes their issues

- sword projectileoverlap is no longer client authoritative. it might feel like ass on client. still works though
- charactermotor onhitground changes have made burrowing inconsistent

![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/AliemMod/Release/_readme/aliem.png)
*someone get me some cool screenshots pls*

### Weapons
There are different primary weapons to choose from.
- Repeatedly press to shoot normally, and hold for an alternate fire that can charge up!
- (You don't have to break your fingers. So long as you are pressing at a reasonable pace, you are considered mashing, and the weapon will fire at max attack speed.)
    - Still, if you have finger problems, you can disable this in config
        - If you don't, give it a chance. it's p fun c:

<img width="550
0" src="https://raw.githubusercontent.com/TheTimeSweeper/the/master/AliemMod/Release/_readme/weapons.png" />

### Leap
Leap on to enemies and ride them, then chomp their heads off

![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/AliemMod/Release/_readme/aliem%20cut_1_1_1_1_optiColor.gif)

## Credits
Dotflare - Model  
rob - Animations  
tsuyoikenko - Gip skin  
The Behemoth - inspiration, sounds 

## Known Issues
- ~~I fuckin fixed them all~~
- ~~if I didn't, let me know~~
- see SotS Fuckery section above

## Future Plans (that I may or may not get to)
- ~~finish him lol~~
- more weapons: BB gun, lightning gun
- more mutations: fire trail, jetpack
- better effects maybe
- more sounds
- enemy version?
- pretty up readme

___
![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/AliemMod/Release/_readme/alienror.png)  
awesome art by `laddestoflads`
___

## Changelog
see changelog tab for more

`1.2.2`
- fixed fps issues

`1.2.1` nevermind DamageAPI is fixed
- returned chomp decapitating and broken achievements
- fixed missing footsteps
- dive can now be aimed downwards (this was in a previous patch idk which)

`1.2.0` half updated for sots
- damagetypes are disabled until r2api.damagetypes is fixed. for now this means:
    - chomp will not do decaptiate effect on kill
    - some achievements are removed, their skills unlocked by default
- sots fuckery. these issues are likely out of my control until gearbox fixes their issues
    - sword projectile is no longer client authoritative. it might feel like ass on client. still works though
    - ~~hold to charge weapons now charge faster/slower based on fps~~
    - ~~sword dash now goes much further/shoerter baed on fps~~
    - ~~human machine gun charged shots shoot much faster/slower based on fps~~
    - ~~close range knife attacks faster/slower based on fps~~
    - charactermotor onhitground changes have made burrowing inconsistent
    - wew
- wip BBGun weapon in cursed config untested for time. will be fixed/released with full patch