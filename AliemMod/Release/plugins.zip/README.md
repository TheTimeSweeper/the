# Aliem
- ~~When will alien hominid invasion come out that shit's gonna be fun~~ it is fun indeed
- happy halloween modjam 2022 c:
- multiplayer compatible!
- overly configurable
- scepter support, emote support
- somewhat-ror-friendly version in config

Anything you'd like to say about the guy, ping me (`thetimesweeper`) on the ror2 modding discord or the enforcer discord (https://discord.gg/GgjjDvStcV).

![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/AliemMod/Release/_readme/aliem.png)
*someone get me some cool screenshots pls*

### Weapons
There are different primary weapons to choose from.
- Repeatedly press to shoot normally, and hold for an alternate fire that can charge up!
- (You don't have to break your fingers. So long as you are pressing at a reasonable pace, you are considered mashing, and the weapon will fire at max attack speed.)
    - Still, if you have finger problems, you can disable this in config
        - If you don't, give it a chance. it's p fun c:

<img width="550
0" src="https://raw.githubusercontent.com/TheTimeSweeper/the/master/AliemMod/Release/_readme/weapons.png" />

### Leap
Leap on to enemies and ride them, then chomp their heads off

![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/AliemMod/Release/_readme/aliem%20cut_1_1_1_1_optiColor.gif)

## Credits
Dotflare - Model  
rob - Animations  
tsuyoikenko - Gip skin  
The Behemoth - inspiration, sounds 

## Known Issues
- I fuckin fixed them all
- if I didn't, let me know

## Future Plans (that I may or may not get to)
- ~~finish him lol~~
- more weapons: BB gun, lightning gun
- more mutations: fire trail, jetpack
- better effects maybe
- more sounds
- enemy version?
- pretty up readme

___
![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/AliemMod/Release/_readme/alienror.png)  
awesome art by `laddestoflads`
___

## Changelog
see changelog tab for more

`1.1.0`
- added config to remove mashing, allowing to simply hold to shoot. this removes the ability to hold to charge of course
    - let me know if this causes any issues
- added new WIP weaopn in cursed config, BBGun
    - Ignore all the empty config entries haha. 
    - let me know if this causes any issues
  - *shoots a ton of bees, but they're optimized as fuck. if you have potato pc please reach out and let me know if it hurts your frames at all*