# Aliem
- ~~When will alien hominid invasion come out that shit's gonna be fun~~ it is fun indeed
- happy halloween modjam 2022 c:
- multiplayer compatible!
- scepter support
- somewhat-ror-friendly version in config

Anything you'd like to say about the guy, ping me (`thetimesweeper`) on the ror2 modding discord or the enforcer discord (https://discord.gg/GgjjDvStcV).

[![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/AliemMod/Release/_readme/aliem.png)]()
*someone get me some cool screenshots pls*

### Weapons
There are different primary weapons to choose from.
- Repeatedly press to shoot normally, and hold for an alternate fire that can charge up!
- (You don't have to break your fingers. So long as you are pressing at a reasonable pace, you are considered mashing, and the weapon will fire at max attack speed.)

[![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/AliemMod/Release/_readme/weapons.png)]()

## Credits
Dotflare - Model  
rob - Animations  
tsuyoikenko - Gip skin  
The Behemoth - inspiration, sounds 

## Known Issues
- I fuckin fixed them all
- if I didn't, let me know

## Future Plans (that I may or may not get to)
- ~~finish him lol~~
- more weapons: BB gun, lightning gun
- more mutations: fire trail, jetpack
- better effects maybe
- more sounds
- enemy version?
- pretty up readme

## Changelog
see changelog tab for more

`1.0.1`
- fixed close range knife not activating always
- tweaked its hitboxes, added it to config
- fixed skins breaking when raindroplobotomy was installed

`1.0.0`
shout out to rob. this update wouldn't have happened if he didn't give the boy some attention
- added energy sword
- added human machine gun
- added sawed off
- added Weapon Swap specials, replacing secondary with a second primary
- added somwhat ror-friendly gup skin (thanks tsuyoikenko!) (config to set as default and change icon)
- solidified mash to shoot and hold to charge functionality for primaries
  - mash at pretty lenient pace and it will auto shoot at max attack speed
  - hold and it will charge up a charged attack
- secondary now fires charged version of primary at max charge, depending on selected primary
- updated most animations and added new ones (thanks rob!)
- a few nerfs for a few reasons. long story short I care about him now
- added configs for pretty much everything, available in Risk of Options
- added shooting while diving and riding
- added armor while diving and riding
- added a double jump which can cancel dive
- severely improved riding presentation
- added hitbox on popping out of burrowing
- added config ability to control movement of the enemy or ally AI you're riding. behind config cause it's probably buggy
- added proper AI
- added shank on close range ray gun (in reference to the original game)
- increased hitbox size of projectiles with respect to enemies but not world
- separated assetbundles n stuff
- added language support