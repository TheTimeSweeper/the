# Aliem
- When will alien hominid invasion come out that shit's gonna be fun
- happy halloween modjam 2022 c:
- multiplayer compatible!

Anything you'd like to say about the guy, ping me (`TheTimesweeper#5727`) on the ror2 modding discord or the enforcer discord (https://discord.gg/ZZzmFgDbCH).

[![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/AliemMod/Release/_readme/aliem.png)]()

## Credits
Dotflare - Model  
The Behemoth - inspiration, sounds 

## Known Issues
- multiplayer
  - animations will get stuck sometimes. 
  - all funcitonality will work fine on your screen, but for others animations may be wonky
- riding not tested on all enemies so there's probably some jank instances
- might be fun might not be fun idk!!

## Future Plans (that I may or may not get to)
- finish him lol
- planned kit 
  - m1 - mash to shoot hold to charge
  - m2 - dive (current shift)
  - shift - fire trail from invasion
  - r - mutations from invasion (so still grenade lol)
- better effects maybe
- more sounds
- replace pod with spaceship that crashes
- enemy version?
- ~~Item displays~~

## Changelog
`0.3.2`
- increased damage on ray gun
  - *projectile is harder to hit (especially in mp), so it can afford to do higher than commando-tier damage*
- increased chomp heal from 10% max health to 30%
- lowered chomp cooldown and damage
- chomp now has `BonusToLowHealth` damage type  

*these changes should hopefully make his kit flow a little better, and give some needed buffs*  
*(from what I know. If I buffed him too much let me know)*

`0.3.1`
- leap now only rides if you're holding the input 
  - config for always ride
  - you're welcome, contra c:
- slightly toned down the range on riding detecting
- readded hitbox to leap
- added scepter why not
- added another silly way to shoot raygun in cursed
- moved up aim origin so projectiles hit the floor less
- reordered so he's not in between tesla trooper and desolator
- fixed stats not being to vanilla standard

`0.3.0`
- fixed projectiles in multiplayer
- fixed riding error spam in multiplayer
- networked riding position for clients. 
  - *each player will see their proper riding position on their screen, but on other screens they will floating behind*
- can now ride allies, which gives them a movement buff
  - *was already giving enemies a movement buff to simulate panicking. simply applies to allies as well*
- chomp now heals for 10% of max health
- borrowed some sounds from the game for his projectiles' impacts
- added his upper and lower jaw to ragdoll

*likely (hopefully, barring bugs) my last update for this guy until I sometime later decide to revisit him*  
*have fun and thanks for havin fun c:*

`0.2.1`
- fixed another bug with ridden enemies dying causing lockups when certain mods were installed
- fixed character collider causing him to spawn through the floor out of the pod
  
`0.2.0`
- added item displays
- chomp now decapitates enemies if it kills them
- fixed bug with riding certain entities
- adjusted character collider to more suit his tiny body

`0.1.0`
- c: