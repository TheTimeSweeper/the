`0.2.0`
- sots fix
- added scepter for primary but that mod's not working yet so uh might be broke
- reduced particle count on m2
- added proper item displays
- really tried to add emotes but couldn't he's too fucked
- joe is also my testing grounds project, so there may be all kinds of nonsense in the cursed config. enjoy

`0.1.0`
- c: