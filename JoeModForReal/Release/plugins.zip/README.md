# Faceless Joe
- Adds Faceless Joe, a fast-paced melee character made just for fun

Anything you'd like to say about the guy, ping me (`TheTimesweeper#5727`) on the ror2 modding discord or the enforcer discord (https://discord.gg/kZPNbXjqBg).  
Was just fuckin around when I made him but all input will still be appreciated.

[![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/JoeModForReal/Release/_readme/css.png)]()

## Overview
- Faceless Joe is a fast-paced in-your-face melee character that uses a mix of movement, armor, and lifesteal to keep him in the fight

## FAQ
- Q: why his model fucked up
  - A: first character I ever concepted, modeled, or animated. I made it a point not to fix any of the issues with it because funny
- Q: Joe? A unique name in Risk of Rain REEEEEE
  - A: Aha but it's not a unique name. Risk of Rain characters usually have general names that can describe anyone in a group of people. Faceless Joe is just that, describes no one in particular. Anyone in Risk of Rain could be called a faceless Joe.
- Q: FAQ before the mod even came out?
  - A: FAQ's are just a good layout for essentially bullet points. In this case (stolen from Tom Scott), FAQ stands for Fully Anticipated Questions

## Credits
literally no one else to credit wow  
uh my mom for giving birth to me

## Known Issues
- just look at him

## Future Plans
- FINALLY GET FUCKING ARTIFACT OF VENGEANCE
- Scepter, Skills++, Emote
- finish item displays
- Character was made just for fun, but if he's enjoyable enough and anyone would like to help with models, animations, icons, etc, I'm down to put in the work making him a real character.

## Changelog

`0.1.0`
- c: