# Faceless Joe
- Adds Faceless Joe. a fast-paced melee character, sure haven't seen any of those before
Anything you'd like to say about the guy, ping me (`TheTimesweeper#5727`) on the ror2 modding discord or the enforcer discord (https://discord.gg/ZZzmFgDbCH).

[![](https://raw.githubusercontent.com/TheTimeSweeper/the/master/Release/Aliem/readme/aliem.pngf)]()

## Credits
literally no one else to credit wow  
uh my mom for giving birth to me  

## FAQ
- Q: why his model fucked up
  - A: first character I ever concepted, modeled, or animated. I made it a point not to fix any of the issues with it because funny
- Q: Faceless Joe? A unique name? This is Risk of Rain reeeeee
  - A: Aha but it's not a unique name. Risk of Rain characters usually have general names that can describe anyone in a group of people. Faceless Joe is just that, describes no one in particular. Anyone in Risk of Rain could be called a Faceless Joe.
- Q: FAQ before the mod even came out?
  - A: FAQ's are just a good layout for bullets. In this case (stolen from Tom Scott), FAQ stands for Fully Anticipated Questions
## Known Issues
- he not done

## Future Plans (that I may or may not get to)
- FINALLY GET FUCKING ARTIFACT OF VENGEANCE

## Changelog

`0.1.0`
- c: