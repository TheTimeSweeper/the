# Changelog
`0.2.0`
- added dependency on FasterPickupText for box upgrade items and crate items
- fixed wrong default values: 
  - *I spent so much time trying to balance this fucker and pushed him out with the wrong numbers*
  - sword match multiplier 2.5x -> 3x
  - sword duration 0.9s -> 0.8s
  - staff base damage 300% -> 500%
  - staff per match damage 200% -> 300%
  - staff2 per match damge 200% -> 300%
  - shield armor 10 -> 20
  - shield max armor 100 -> 120
  - key unlock base value 1.5 -> 2
  - key unlock percent value 0% -> 1%
  - configs reset

`0.1.0`
- c:
