# Match Maker

Adds the Match Maker. Pull up a match-3 grid and match tiles to boost your abilities
- yes really
    - I spent way too much time on this
- fully multiplayer compatible
    - yes really
        - I spent way too much time on this
- fully configurable
- sorry I did this instead of like the 5 other more important things I need to do

Feedback absolutely welcome! Reach out to me (`thetimesweeper`) on the ror2 modding discord or the enforcer discord (https://discord.gg/GgjjDvStcV) and let me know what you think!

![](https://raw.githubusercontent.com/TheTimeSweeper/the/refs/heads/master/MatchMaker/Release/_misc/matcher_css.png)
![](https://raw.githubusercontent.com/TheTimeSweeper/the/refs/heads/master/MatchMaker/Release/_misc/matcher_match.png)
![](https://raw.githubusercontent.com/TheTimeSweeper/the/refs/heads/master/theUnityProject/Assets/_Characters/MatchMaker/MatcherBundle/Icons/texIconMatcher.png)


## Credits
- SkeletorChampion: 
  - Model
- Luca Redwood (EightyEight Games ([You Must Build a Boat](https://store.steampowered.com/app/290890/You_Must_Build_A_Boat/?curator_clanid=34686623) and [10,000,000](https://store.steampowered.com/app/227580/10000000/?curator_clanid=34686623))): 
  - Gameplay Inspiration, Tile icons.
  
## Known Issues/todo
- alternate 4th tiles are not networked
- sounds lacking
- effects lacking
